<?php $__env->startSection('title', "Lihat <?php echo e($car->model); ?>"); ?>

<?php $__env->startSection('main'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Detail tentang mobil</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.car.index')); ?>">Mobil</a></li>
            <li class="breadcrumb-item active"><?php echo e($car->model.' '.$car->brand); ?></li>
        </ol>
        <!-- <div class="card mb-4">
            <div class="card-body">
                Di sini Anda dapat melihat semua mobil di parkir kami.
            </div>
        </div>-->
        <div class="mb-4">
            <div class="card">
                <div class="card-header">
                    <h4><?php echo e($car->brand); ?> <?php echo e($car->model); ?></h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <img src="<?php echo e(Storage::url($car->image_url)); ?>" class="img-fluid" alt="Gambar Utama Mobil">
                        </div>
                        <div class="col-md-6">
                            <ul class="list-group">
                                <li class="list-group-item"><strong>Tahun Pembuatan:</strong> <?php echo e($car->make_year); ?></li>
                                <li class="list-group-item"><strong>Jumlah Kursi:</strong> <?php echo e($car->passenger_capacity); ?></li>
                                <li class="list-group-item"><strong>Kilometer per Liter:</strong> <?php echo e($car->kilometers_per_liter); ?></li>
                                <li class="list-group-item"><strong>Jenis Bahan Bakar:</strong> <?php echo e($car->fuel_type); ?></li>
                                <li class="list-group-item"><strong>Jenis Transmisi:</strong> <?php echo e($car->transmission_type); ?></li>
                                <li class="list-group-item"><strong>Harga Sewa per Hari:</strong> <?php echo e($car->daily_rate); ?></li>
                            </ul>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <h5>Gambar-gambar Sekunder:</h5>
                        </div>
                    </div>
                    <div class="row">
                        <?php $__currentLoopData = $car->secondaryImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mt-3">
                            <img src="<?php echo e(Storage::url($image->url)); ?>" class="img-fluid" alt="Gambar Sekunder Mobil">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <div class="text-center">
                                <a type="button" class="btn btn-primary mr-2 disabled" href="<?php echo e(route('admin.car.edit', ['id' => $car->id])); ?>">Edit</a>
                                <button type="button" class="btn btn-danger" onclick="if(confirm('Apakah Anda yakin ingin menghapus mobil ini?')) { document.getElementById('delete-form').submit(); }">Hapus</button>
                                <form id="delete-form" action="<?php echo e(route('admin.car.destroy', ['id' => $car->id])); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cardex\resources\views/admin/car-details.blade.php ENDPATH**/ ?>