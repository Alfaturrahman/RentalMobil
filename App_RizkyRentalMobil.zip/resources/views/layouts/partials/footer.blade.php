<footer class="footer">
  <div class="container">
      <div class="row">
          <div class="col-md-3">
              <h4>Tentang kami</h4>
              <p>Di Rizky Rental Mang, kami unggul dengan armada kendaraan berkualitas, layanan pelanggan yang ramah dan profesional, serta proses pemesanan yang mudah dan fleksibel.
                kami memiliki solusi yang tepat untuk setiap kebutuhan perjalanan Anda. Percayakan perjalanan Anda kepada kami dan rasakan perbedaannya bersama Rizky Rental Mang.</p>
          </div>
          <div class="col-md-3">
              <h4>Menu Links</h4>
              <ul>
                  <li><a href="{{ route('home.index') }}">Beranda</a></li>
                  <li><a href="{{ route('car.index') }}">Tentang Kami</a></li>
                  <li><a href="{{ route('about.show') }}">Sewa</a></li>
                  <li><a href="{{ route('contacts.show') }}">Kontak</a></li>
              </ul>
          </div>
          <div class="col-md-3">
            <h4>Kontak</h4>
            <div class="column">
              <div class="row">
                <i class="fas fa-car"></i> <span> +62 8782 255 3252 </span>
              </div>
              <div class="row">
                <i class="fas fa-car"></i> <span> 087822553252 </span>
              </div>
              <div class="row">
                <i class="fas fa-car"></i> <span> eky.syahputra3107@gmail.com </span>
              </div>
            </div>
          </div>
          <div class="col-md-3">
              <h4>Alamat</h4>
              <p>Batam, Kota Batam, Kepulauan Riau</p>
          </div>
      </div>
  </div>
</footer>
