<?php

    var_dump($data);