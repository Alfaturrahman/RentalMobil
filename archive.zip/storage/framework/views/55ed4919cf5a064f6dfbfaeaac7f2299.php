<?php $__env->startSection('title', 'Kendaraan'); ?>

<?php $__env->startSection('main'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Daftar Kendaraan</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Beranda</a></li>
            <li class="breadcrumb-item active">Kendaraan</li>
        </ol>
        <!-- <div class="card mb-4">
            <div class="card-body">
                Di sini Anda dapat melihat semua mobil di parkir kami.
            </div>
        </div>-->
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <div class="mb-4">
            <div>
                <a class="btn btn-primary m-3" href="<?php echo e(route('admin.car.create')); ?>" role="button">Tambahkan</a>
            </div>
            <div table-responsive>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Model</th>
                            <th>Merek</th>
                            <th>Harga per Hari</th>
                            <th>Tersedia</th>
                            <th>Tindakan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($car->id); ?></td>
                            <td><?php echo e($car->model); ?></td>
                            <td><?php echo e($car->brand); ?></td>
                            <td><?php echo e($car->daily_rate); ?></td>
                            <td><?php echo e($car->available ? 'Tersedia' : 'Tidak Tersedia'); ?></td>
                            <td>
                                <div class="dropdown open">
                                    <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        Opsi
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.car.show', ['id' => $car->id])); ?>">Lihat</a></li>
                                        <li><a class="dropdown-item disabled" href="<?php echo e(route('admin.car.edit', ['id' => $car->id])); ?>">Ubah</a></li>
                                        <li><button type="button" class="dropdown-item" onclick="if(confirm('Apakah Anda yakin ingin menghapus mobil ini?')) { document.getElementById('delete-form').submit(); }">Hapus</button>
                                            <form id="delete-form" action="<?php echo e(route('admin.car.destroy', ['id' => $car->id])); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($cars->links()); ?>

            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\App_RizkyRentalMobil\resources\views/admin/cars.blade.php ENDPATH**/ ?>