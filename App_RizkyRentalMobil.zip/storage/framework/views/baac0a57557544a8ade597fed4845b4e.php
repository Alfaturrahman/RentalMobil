<?php $__env->startSection('title', 'Contacts'); ?>

<?php $__env->startSection('main'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cardex\resources\views/contacts.blade.php ENDPATH**/ ?>