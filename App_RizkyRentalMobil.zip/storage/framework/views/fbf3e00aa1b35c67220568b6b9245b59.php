<?php $__env->startSection('title', 'Pendaftaran'); ?>

<?php $__env->startSection('body'); ?>
<!-- konten utama -->
<main class="main main--sign" data-bg="img/bg/bg.png">
    <!-- formulir pendaftaran -->
    <div class="sign">
        <div class="sign__content">
            <form action="<?php echo e(route('register.perform')); ?>" method="POST" class="sign__form">
                <?php echo csrf_field(); ?>
                <a href="<?php echo e(route('home.index')); ?>" class="sign__logo">
                    <img src="<?php echo e(asset('img/rentallogo.png')); ?>" alt="" style="height: auto; width:150px">  
                </a>

                <?php if($errors->has('first_name')): ?>
                    <span class="text-danger text-center"><?php echo e($errors->first('first_name')); ?></span>
                <?php endif; ?>
                <div class="sign__group">
                    <input type="text" name="first_name" class="sign__input" placeholder="Nama depan">
                </div>
    
                <?php if($errors->has('last_name')): ?>
                    <span class="text-danger text-center"><?php echo e($errors->first('last_name')); ?></span>
                <?php endif; ?>
                <div class="sign__group">
                    <input type="text" name="last_name" class="sign__input" placeholder="Nama belakang">
                </div>
                
                <?php if($errors->has('email')): ?>
                    <span class="text-danger text-center"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
                <div class="sign__group">
                    <input type="email" name="email" class="sign__input" placeholder="Email">
                </div>

                <?php if($errors->has('phone')): ?>
                    <span class="text-danger text-center"><?php echo e($errors->first('phone')); ?></span>
                <?php endif; ?>
                <div class="sign__group">
                    <input type="tel" name="phone" class="sign__input" placeholder="Nomor Telepon">
                </div>

                <?php if($errors->has('date_of_birth')): ?>
                    <span class="text-danger text-center"><?php echo e($errors->first('date_of_birth')); ?></span>
                <?php endif; ?>
                <div class="sign__group">
                    <input type="date" name="date_of_birth" class="sign__input" placeholder="Tanggal lahir">
                </div>

                <?php if($errors->has('password')): ?>
                    <span class="text-danger text-center"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
                <div class="sign__group">
                    <input type="password" name="password" class="sign__input" placeholder="Kata Sandi">
                </div>


                <button class="sign__btn" type="submit"><span>Daftar</span></button>

                <span class="sign__text">Sudah punya akun? <a href="<?php echo e(route('login.show')); ?>">Masuk!</a></span>
            </form>
        </div>
    </div>
    <!-- end formulir pendaftaran -->
</main>
<!-- end konten utama -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cardex\resources\views/auth/register.blade.php ENDPATH**/ ?>