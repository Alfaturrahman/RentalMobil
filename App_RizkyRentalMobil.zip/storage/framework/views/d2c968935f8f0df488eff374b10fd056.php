<?php $__env->startSection('title', "Modifier location"); ?>

<?php $__env->startSection('main'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Modifier une location</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Accueil</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.rent.index')); ?>">Locations</a></li>
            <li class="breadcrumb-item active">Modifier <?php echo e($rent->id); ?></li>
        </ol>
        <!-- <div class="card mb-4">
            <div class="card-body">
                Ici vous pouvez voir toute les voitures de notre parking.
            </div>
        </div>-->
        <div class="mb-4">
            <div class="card">
                <div class="card-header">
                    <h4>Location n<?php echo e($rent->id); ?></h4>
                </div>
                <div class="card-body">
                    En developpement...    
                </div>
            </div>

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cardex\resources\views/admin/rent-edit.blade.php ENDPATH**/ ?>