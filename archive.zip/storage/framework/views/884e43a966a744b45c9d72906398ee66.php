<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Halaman Tidak Ditemukan</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/error.css')); ?>">
</head>
<body>
    <div class="container">
        <h1>404 - Halaman Tidak Ditemukan</h1>
        <p>Maaf, halaman yang Anda cari tidak ditemukan.</p>
        <a href="<?php echo e(route('home.index')); ?>">Kembali ke Beranda</a>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\App_RizkyRentalMobil\resources\views/errors/404.blade.php ENDPATH**/ ?>