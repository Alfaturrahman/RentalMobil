<?php $__env->startSection('title', 'Pendaftaran'); ?>

<?php $__env->startSection('body'); ?>
<!-- konten utama -->
<main class="main main--sign" data-bg="img/bg/bg.png">
    <!-- formulir pendaftaran -->
    <div class="sign">
        <div class="sign__content">
            <form action="<?php echo e(route('admin.register.perform')); ?>" method="POST" class="sign__form">
                <?php echo csrf_field(); ?>
                <h2>Administrasi</h2>
                <a href="<?php echo e(route('home.index')); ?>" class="sign__logo">
                    <img src="<?php echo e(asset('img/rentallogo.png')); ?>" alt="" style="height: auto; width:150px">
                </a>

                <?php if($errors->has('username')): ?>
                    <span class="text-danger text-center"><?php echo e($errors->first('username')); ?></span>
                <?php endif; ?>
                <div class="sign__group">
                    <input type="text" name="username" class="sign__input" placeholder="Nama Administrator">
                </div>
    
                <?php if($errors->has('fullname')): ?>
                    <span class="text-danger text-center"><?php echo e($errors->first('fullname')); ?></span>
                <?php endif; ?>
                <div class="sign__group">
                    <input type="text" name="fullname" class="sign__input" placeholder="Nama Lengkap">
                </div>
                
                <?php if($errors->has('email')): ?>
                    <span class="text-danger text-center"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
                <div class="sign__group">
                    <input type="email" name="email" class="sign__input" placeholder="Email">
                </div>

                <?php if($errors->has('password')): ?>
                    <span class="text-danger text-center"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
                <div class="sign__group">
                    <input type="password" name="password" class="sign__input" placeholder="Kata Sandi">
                </div>


                <button class="sign__btn" type="submit"><span>Daftar</span></button>

                <span class="sign__text">Sudah memiliki akun? <a href="<?php echo e(route('admin.login.show')); ?>">Masuk!</a></span>
            </form>
        </div>
    </div>
    <!-- end formulir pendaftaran -->
</main>
<!-- end konten utama -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cardex\resources\views/admin/auth/register.blade.php ENDPATH**/ ?>