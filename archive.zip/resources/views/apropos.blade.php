@extends('layouts.master')

@section('title', 'A propos')

@section('main')

@endsection