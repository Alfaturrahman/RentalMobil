<?php $__env->startSection('title', 'Not found'); ?>

<?php $__env->startSection('body'); ?>
    <!-- main content -->
	<main class="main main--sign" data-bg="img/bg/bg.png">
		<!-- error -->
		<div class="page-404">
			<div class="page-404__wrap">
				<div class="page-404__content">
					<h1 class="page-404__title">404</h1>
					<p class="page-404__text">La page que vous cherchez n'est pas disponible!</p>
					<a href="<?php echo e(route('home.index')); ?>" class="page-404__btn"><span>Revenir en arrière</span></a>
				</div>
			</div>
		</div>
		<!-- end error -->
	</main>
	<!-- end main content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cardex\resources\views/errors/404.blade.php ENDPATH**/ ?>